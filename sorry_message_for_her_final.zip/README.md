# Sorry ❤️

![us](us_mirror.png)

**Hayoo lovelove denden ko,**  

Sorry man po love I didn’t make pansin sa story mo and I just said *jhiejhiemon*, when instead I could have said there na *DAMN LOVEE YOU SO PRETTYY MAN THAT’S MY GF, TAENA LOVE ANG GANDA MO TALGAAAA.*  

And sorry love I didn’t make *kamusta* sayo while reviewing ka — didn’t get to say na mag-rest ka din kahit paano and wag i-stress sarili mo masyado.  

Sorry love, here’s my *bawi* man po. I’m really sorry baby ko. **I love you!** ❤️  

**AND LOVE YOU ARE SO PRETTY BABY KO AND REMEMBER THAT AND GO ACE UR PRELIMS KAYANG KAYA MO YAN MWUAH 💋**  

**Always yours,**  
— *CK*
